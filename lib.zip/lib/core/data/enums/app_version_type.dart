enum AppVersionType { expired, haveUpdate, upToDate }
