enum DiscountType { percentage, nominal }
