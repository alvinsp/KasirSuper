enum Status { initial, loading, apply, processed, deleted, success, failure }
