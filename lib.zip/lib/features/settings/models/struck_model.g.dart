// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'struck_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

StruckModel _$StruckModelFromJson(Map<String, dynamic> json) => StruckModel(
      desc: json['desc'] as String?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$StruckModelToJson(StruckModel instance) =>
    <String, dynamic>{
      'desc': instance.desc,
      'message': instance.message,
    };
